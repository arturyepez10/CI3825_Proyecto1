#ifndef LOOK_h
#define LOOK_h

void recursive_tree(char *basePath, const int root, int bool1, int v);
int readTar(char *path);
#endif