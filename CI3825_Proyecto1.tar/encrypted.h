#ifndef ENCRYPTED_h
#define ENCRYPTED_h

int rotarIzquierda(int n, unsigned int rotacion);

int rotarDerecha(int n, unsigned int rotacion);

#endif