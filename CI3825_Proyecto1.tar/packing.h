#ifndef PACKING_h
#define PACKING_h

void recursive_tree(char *basePath, const int root, int n, int v);

#endif